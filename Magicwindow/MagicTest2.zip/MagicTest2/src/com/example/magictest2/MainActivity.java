package com.example.magictest2;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import cn.magicwindow.*;
import android.util.Log;
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	Log.d("xieyi","helloworld");
    	super.onCreate(savedInstanceState);
    	//ħ����ʼ
    	MWConfiguration config = new MWConfiguration(this); 
    	config.setChannel("Ӧ�ñ�")
		.setLogEnable(true)
		. setPageTrackWithFragment(true);
    	Log.d("xieyi","MWversion"+MagicWindowSDK.getSDKVersion());
    	//ע��mlink
    	MLinkAPIFactory.createAPI(this).registerWithAnnotation(this);
    	//ħ������
    	Log.d("xieyi","MWversion"+getIntent().getData());
    	if(getIntent().getData()!=null){
    		MLinkAPIFactory.createAPI(this).router(this, getIntent().getData());
    		Log.d("xieyi","MWversion"+" router is called");
    	}
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
    }
    @Override
    protected void onStart() {
      super.onStart();
      Uri mLink = getIntent().getData();
      if (mLink != null) {
    	  MLinkAPIFactory.createAPI(this).router(mLink);
      } else {
       
       Log.d("xieyi", "MWversion onStart");
          //MLink.getInstance(this).checkYYB();
      }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    protected void onPause() {
            Session.onPause(this);
            super.onPause();
        }
    @Override
    protected void onResume() {
            Session.onResume(this);
            super.onResume();
    }
}
