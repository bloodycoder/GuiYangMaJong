package com.example.magictest2;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import cn.magicwindow.*;
import cn.magicwindow.mlink.annotation.MLinkDefaultRouter;
import android.util.Log;
@MLinkDefaultRouter
public class HomeActivity extends Activity {
	 protected void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
	     Log.d("xieyi","MWversion HomeActivity is called");
	     setContentView(R.layout.activity_main);
	 }
}
