package com.example.magictest2;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import cn.magicwindow.*;
import cn.magicwindow.mlink.annotation.MLinkDefaultRouter;
import cn.magicwindow.mlink.annotation.MLinkRouter;
import android.util.Log;
@MLinkRouter(keys={"windowtest"})
public class DetailActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("xieyi","MWversion DetailActivity is called");
		   //ͨ��intent��ʽ��ȡ��̬����ֵ
        Intent intent = getIntent();
        if (intent != null) {
            String param = intent.getStringExtra("room_id");
            Log.d("xieyi","MWversion Room_id is "+param);
        }
    }
}